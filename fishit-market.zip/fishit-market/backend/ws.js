import { WebSocketServer } from "ws"

export function initWS(server) {
  const wss = new WebSocketServer({ server })
  const clients = new Set()

  wss.on("connection", ws => {
    ws.isAlive = true
    clients.add(ws)

    // kirim info awal
    ws.send(JSON.stringify({
      type: "connected",
      message: "Realtime Fish It Market aktif"
    }))

    // heartbeat
    ws.on("pong", () => {
      ws.isAlive = true
    })

    ws.on("close", () => {
      clients.delete(ws)
    })

    ws.on("error", () => {
      clients.delete(ws)
    })
  })

  // cleanup client mati
  const interval = setInterval(() => {
    clients.forEach(ws => {
      if (!ws.isAlive) {
        ws.terminate()
        clients.delete(ws)
      } else {
        ws.isAlive = false
        ws.ping()
      }
    })
  }, 30000)

  wss.on("close", () => {
    clearInterval(interval)
  })

  // fungsi broadcast
  function broadcast(data) {
    const msg = JSON.stringify(data)
    clients.forEach(ws => {
      if (ws.readyState === ws.OPEN) {
        ws.send(msg)
      }
    })
  }

  return { broadcast }
}