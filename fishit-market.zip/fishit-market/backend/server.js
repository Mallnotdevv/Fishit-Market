import express from "express"
import fs from "fs"
import cors from "cors"
import http from "http"
import fetch from "node-fetch"
import { WebSocketServer } from "ws"

// ==================
// BASIC SETUP
// ==================
const app = express()
const DB_PATH = "./backend/db.json"
const DISCORD_WEBHOOK = process.env.DISCORD_WEBHOOK || null

app.use(cors())
app.use(express.json())
app.use(express.static("public"))

// ==================
// DB HELPER
// ==================
const readDB = () =>
  JSON.parse(fs.readFileSync(DB_PATH, "utf-8"))

const writeDB = (data) =>
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2))

// ==================
// ROUTES
// ==================

// PUBLIC – GET ALL PRICES
app.get("/api/prices", (req, res) => {
  res.json(readDB().items)
})

// ADMIN LOGIN
app.post("/api/login", (req, res) => {
  const { username, password } = req.body
  const db = readDB()

  if (
    username === db.admin.username &&
    password === db.admin.password
  ) {
    return res.json({ success: true, token: "admin-token" })
  }

  res.status(401).json({ success: false })
})

// ADMIN UPDATE PRICE
app.post("/api/update", async (req, res) => {
  const { token, name, price } = req.body
  if (token !== "admin-token")
    return res.status(403).json({ error: "unauthorized" })

  const db = readDB()
  const item = db.items.find(i => i.name === name)
  if (!item)
    return res.status(404).json({ error: "item ga ada" })

  const oldPrice = item.price
  item.price = Number(price)
  item.updated = new Date().toISOString().slice(0, 10)
  writeDB(db)

  // ==================
  // REALTIME BROADCAST
  // ==================
  broadcast({
    type: "price-update",
    item
  })

  // ==================
  // DISCORD NOTIF
  // ==================
  if (DISCORD_WEBHOOK) {
    const diff = item.price - oldPrice
    const percent = oldPrice
      ? ((diff / oldPrice) * 100).toFixed(2)
      : "0.00"

    let trend = "STABLE"
    let emoji = "⏸"
    let color = 9807270

    if (diff > 0) {
      trend = "NAIK"
      emoji = "📈"
      color = 5763719
    } else if (diff < 0) {
      trend = "TURUN"
      emoji = "📉"
      color = 15548997
    }

    await fetch(DISCORD_WEBHOOK, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        embeds: [{
          title: `${emoji} Update Harga Fish It`,
          color,
          fields: [
            { name: "🐟 Item", value: item.name, inline: true },
            { name: "💎 Rarity", value: item.rarity, inline: true },
            { name: "📊 Status", value: trend, inline: true },
            {
              name: "💰 Harga Lama",
              value: `Rp ${oldPrice.toLocaleString()}`,
              inline: true
            },
            {
              name: "💵 Harga Baru",
              value: `Rp ${item.price.toLocaleString()}`,
              inline: true
            },
            {
              name: "📉 Selisih",
              value: `${diff > 0 ? "+" : ""}${diff.toLocaleString()} (${percent}%)`
            }
          ],
          footer: {
            text: "Fish It Market • Realtime"
          },
          timestamp: new Date()
        }]
      })
    })
  }

  res.json({ success: true })
})

// ==================
// AUTO PORT + WS
// ==================
const BASE_PORT = process.env.PORT
  ? Number(process.env.PORT)
  : 3000

let wss
function broadcast(data) {
  if (!wss) return
  const msg = JSON.stringify(data)
  wss.clients.forEach(c => {
    if (c.readyState === 1) c.send(msg)
  })
}

function startServer(port) {
  const server = http.createServer(app)
  wss = new WebSocketServer({ server })

  wss.on("connection", ws => {
    ws.send(JSON.stringify({
      type: "connected",
      message: "Realtime active"
    }))
  })

  server.listen(port, () => {
    console.log(`
====================================
🐟 Fish It Market Running
🌐 http://localhost:${port}
⚡ Realtime + Discord ON
====================================
`)
  })

  server.on("error", err => {
    if (err.code === "EADDRINUSE") {
      console.log(`⚠️ Port ${port} dipakai, pindah ke ${port + 1}`)
      startServer(port + 1)
    } else {
      console.error(err)
    }
  })
}

startServer(BASE_PORT)