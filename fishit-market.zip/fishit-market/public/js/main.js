let items = []

const grid = document.getElementById("grid")
const search = document.getElementById("search")
const sort = document.getElementById("sort")
const count = document.getElementById("count")

// ===== FETCH =====
fetch("/api/prices")
  .then(r => r.json())
  .then(data => {
    items = data
    render()
  })

// ===== RENDER =====
function render() {
  let data = [...items]

  const q = search.value.toLowerCase()
  if (q) {
    data = data.filter(i =>
      i.name.toLowerCase().includes(q)
    )
  }

  if (sort.value === "high") {
    data.sort((a,b) => b.price - a.price)
  } else if (sort.value === "low") {
    data.sort((a,b) => a.price - b.price)
  }

  count.textContent = `${data.length} items ditemukan`

  grid.innerHTML = data.map(i => `
    <div class="card" data-name="${i.name}">
      <div class="info">
        <div class="name">${i.name}</div>
        <div class="meta">${i.rarity}</div>
        <div class="price">Rp ${i.price.toLocaleString()}</div>
        <div class="signal" id="signal-${i.name}">—</div>
        <div class="time">Update: ${timeAgo(i.updated)}</div>
      </div>
    </div>
  `).join("")
}

// ===== SEARCH + SORT =====
search.oninput = render
sort.onchange = render

// ===== WEBSOCKET =====
const wsProto = location.protocol === "https:" ? "wss" : "ws"
const ws = new WebSocket(`${wsProto}://${location.host}`)

ws.onmessage = e => {
  const msg = JSON.parse(e.data)
  if (msg.type !== "price-update") return

  const upd = msg.item
  const idx = items.findIndex(i => i.name === upd.name)
  if (idx === -1) return

  const old = items[idx].price
  items[idx] = upd

  const card = document.querySelector(`.card[data-name="${upd.name}"]`)
  if (!card) return render()

  const priceEl = card.querySelector(".price")
  const signalEl = card.querySelector(".signal")

  priceEl.textContent = `Rp ${upd.price.toLocaleString()}`

  card.classList.remove("up","down")
  if (upd.price > old) {
    card.classList.add("up")
    signalEl.textContent = "▲ Harga naik"
  } else if (upd.price < old) {
    card.classList.add("down")
    signalEl.textContent = "▼ Harga turun"
  } else {
    signalEl.textContent = "— Stabil"
  }

  card.classList.add("flash")
  setTimeout(() => card.classList.remove("flash"), 1200)
}

// ===== TIME AGO =====
function timeAgo(date) {
  const diff = (Date.now() - new Date(date)) / 60000
  if (diff < 1) return "baru saja"
  if (diff < 60) return `${Math.floor(diff)} menit lalu`
  return `${Math.floor(diff/60)} jam lalu`
}